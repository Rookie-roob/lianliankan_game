package lianliankan;

import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Reflash {
	//����ʱ��Ҫˢ�º���
public static void renew (Element[] a,int k,JPanel matrixpnl)
{
	ArrayList<Integer> p=RandomList.returnlist(k);
	for(int i=1;i<=k/2;i++)
	{
		Element temp=a[p.get(i-1)];
		a[p.get(i-1)]=a[p.get(56-i)];
		a[p.get(56-i)]=temp;
	}
	matrixpnl.removeAll();
	matrixpnl.setVisible(false);
	for(int i=1;i<=56;i++)
	{
		matrixpnl.add(a[i-1]);
	}
}
}
