package lianliankan;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;




//����ʱ60s����һ��
public class CountDown60 {
static int i=90;
static Element[] tempet;
public void cd60(JLabel jb,JFrame p,JPanel matrixpnl,Object[] overchoose,Element[] elegp,int numelt,int numpic)
{
	jb.setText("90");
	Timer timer=new Timer();
	Date date=new Date();
	timer.schedule(new TimerTask()
			{
		public void run()
		{
			if(i>=0)
			{
				jb.setText(i+"");
				i--;
				if(MainFrame.currentscore==56)
				{
					 int optionSelected1 = JOptionPane.showOptionDialog(
			                   p,
			                   "��ϲ�㣬ͨ����������",
			                   "��ʾ",
			                   JOptionPane.YES_NO_CANCEL_OPTION,
			                   JOptionPane.INFORMATION_MESSAGE,
			                   new ImageIcon("src/lianliankan/chooseimage1.png"),
			                   MainFrame.finishgame,    // �����null, ��ťΪ optionType ��������ʾ�İ�ť��Ҳ����ȷ�϶Ի���
			                   MainFrame.finishgame[0]);
					 //��¼�´�ʱ�ķ����Լ�ʹ�õ�ʱ��
					 MainFrame.finalscore=56;
					 MainFrame.usedtime=(90-i);
					 
					 //ȡ����ʱ�ļ�ʱ�߳�
					 timer.cancel();
					 
					 //ѡ���˳��������棬��ֱ���˳�
					 if(optionSelected1==0)
					 {
					     System.exit(0);			
					 }
					 else if(optionSelected1==1)
					 {
						 //�ϴ�ս����������ʱ���ϴ������磩
						 String id = JOptionPane.showInputDialog("Please input your id"); 
						 new Client(id,MainFrame.usedtime).createcl();
						 System.exit(0);
					 }
				}
				else if(i==-1)
				{
					 int optionSelected = JOptionPane.showOptionDialog(
			                   p,
			                   "ʱ�䵽��������",
			                   "��ʾ",
			                   JOptionPane.YES_NO_CANCEL_OPTION,
			                   JOptionPane.INFORMATION_MESSAGE,
			                   new ImageIcon("src/lianliankan/chooseimage1.png"),
			                   overchoose,    // �����null, ��ťΪ optionType ��������ʾ�İ�ť��Ҳ����ȷ�϶Ի���
			                   overchoose[0]);
					 timer.cancel();
					 if (optionSelected==1)
					 {
						 //�˳����浵����
						Date d1=new Date();
						SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String d1s=sdf.format(d1);
						recordunfinished ru1=new recordunfinished();
						ru1.recordscore(MainFrame.currentscore, d1s);
						System.exit(0);
					 }
					 else
					 {
						 MainFrame.ready=false;
						 jb.setText("90");
						 tempet=new Element[56];
			        	   for(int i=1;i<=56;i++)
			        	   {
			        		   tempet[i-1]=new Element();
			        	   }
			        	   matrixpnl.removeAll();
			        	   matrixpnl.setVisible(false);
			        	   initialrange v=new initialrange();
			        	   tempet=v.initial(tempet, 56, 7);
			        	   for(int i=1;i<=56;i++)
			        	   {
			        		   matrixpnl.add(tempet[i-1]);
			        		   tempet[i-1].setFocusPainted(false);
			        		   tempet[i-1].setBorder(BorderFactory.createLineBorder(Color.BLACK));
			        	   }
			        	   MainFrame.elementgp=tempet;
			        	 matrixpnl.setVisible(true);
			        	 MainFrame.returnsjb ().setText("0");
						 i=90;
						 MainFrame.currentscore=0;
						 for(Element z:tempet)
			        	   {
			        		   z.addMouseListener(new MouseAdapter()
			        				   {
			        			   public void mouseClicked(MouseEvent e)
			        			   {
			        				   gamealg s=new gamealg();
			        				   s.gameway(z, tempet, 56, 7, 8, MainFrame.returnsjb (), MainFrame.currentscore);
			        			   }
			        				   });
			        		 
			        	   }
					 }
				}
			}
		}
			}, date, 1000);
}
}
