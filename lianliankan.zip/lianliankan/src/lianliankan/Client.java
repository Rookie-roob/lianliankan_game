package lianliankan;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

public class Client {
	String id;
	int score;
	String totalmessage;//��id��score�ϲ�
	public Client(String id,int score)
	{
		this.id=id;
		this.score=score;
		this.totalmessage=id+" "+Integer.toString(score);
	}
	public Client(String bool)
	{
		totalmessage="true";
	}
	public void createcl()
	{
try {
	if(totalmessage!="true")
	{
	Socket s=new Socket(InetAddress.getByName("DESKTOP-L2T7CKA"),10005);
	OutputStream os1=s.getOutputStream();
	byte[] bytes=totalmessage.getBytes();
	os1.write(bytes);
	s.shutdownOutput();//�ر��������һ���ź�
	s.close();
	}
	else
	{
		Socket s2=new Socket(InetAddress.getByName("DESKTOP-L2T7CKA"),10005);
		OutputStream os1=s2.getOutputStream();
		byte[] bytes=totalmessage.getBytes();
		os1.write(bytes);
		s2.shutdownOutput();//�ر��������һ���ź�
	//�����а���Ϣ
	BufferedReader br2=new BufferedReader(new InputStreamReader(s2.getInputStream()));//������
	listdata.iddata=new ArrayList<String>();
	listdata.scoredata=new ArrayList<String>();
	int flag=1;
	String line1;
	//�����а���Ϣ�洢��listdata��
	while((line1=br2.readLine())!=null)//������
	{
		if(flag%2==1)
		{
			listdata.iddata.add(line1);
			flag++;
		}
		else
		{
			listdata.scoredata.add(line1);
			flag++;
		}
	}
	br2.close();
	s2.close();
	}
} catch (UnknownHostException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}
}
