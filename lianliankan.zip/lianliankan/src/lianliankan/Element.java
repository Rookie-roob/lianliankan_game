package lianliankan;

import javax.swing.JButton;

public class Element extends JButton{
boolean ismatched=false;
boolean isclicked=false;
}
