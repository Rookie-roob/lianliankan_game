package lianliankan;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class recordunfinished {
public void recordscore(int score,String time)
{
	//�Ƚ��ж���������ԭ�ȵ�fail���ݶ�ȡ
	try
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("src/lianliankan/unfinished.txt")));
		String line;
		ArrayList<String> h=new ArrayList<String> ();
		while((line=br.readLine())!=null)
		{
			h.add(line);
		}
		br.close();
		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/lianliankan/unfinished.txt")));
		int len=h.size();
		for(int i=0;i<len;i++)
		{
			bw.write(h.get(i));
			bw.newLine();
		}
		bw.write(time+"    ----    "+score);
		bw.newLine();
		bw.close();
	}catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
