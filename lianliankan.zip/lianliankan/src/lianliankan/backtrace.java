package lianliankan;

import java.util.ArrayList;

public class backtrace {
static ArrayList<Integer> deletenum;
static int totaldel;
}
