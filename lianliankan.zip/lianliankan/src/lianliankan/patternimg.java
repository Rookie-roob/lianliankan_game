package lianliankan;

import javax.swing.ImageIcon;

public class patternimg {
static ImageIcon[] iconlt=new ImageIcon[] {new ImageIcon("src/lianliankan/1.png"),
		new ImageIcon("src/lianliankan/2.png"),
		new ImageIcon("src/lianliankan/3.png"),
		new ImageIcon("src/lianliankan/4.png"),
		new ImageIcon("src/lianliankan/5.png"),
		new ImageIcon("src/lianliankan/6.png"),
		new ImageIcon("src/lianliankan/7.png")};
}
