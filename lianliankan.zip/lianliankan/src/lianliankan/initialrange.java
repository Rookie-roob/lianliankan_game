package lianliankan;

import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;

public class initialrange {
public Element[] initial(Element[] a,int k,int picnum)
{
	ArrayList<Integer> x=RandomList.returnlist(k);
	int g=0;
	while(g<=((k/2)-1))
	{
		
		a[x.get(g*2).intValue()].setIcon(patternimg.iconlt[(g/2)%picnum]);
		a[x.get(g*2+1).intValue()].setIcon(patternimg.iconlt[(g/2)%picnum]);
		g++;
	}
	return a;
}
}
