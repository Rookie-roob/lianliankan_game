package lianliankan;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class MainFrame extends JFrame{
private JButton play;
private JPanel imagepanel;
private ImageIcon background;
private JLabel backgroundlbl;
private JLabel title;
private ImageIcon titlepic;
private JButton help;
private JDialog helpdg;
private static JLabel score;
private JLabel time;
private JPanel messagepnl;
private JPanel matrixpnl;
private JPanel leftpnl;
private JPanel rightpnl;
private JPanel uppnl;
private JLabel timetext;
private JLabel scoretext;
private JButton reflash;
public Object[] gameovergp = new Object[] {"��ʼ����Ϸ","�˳������ر�������"};
public static Object[] finishgame=new Object[] {"�˳���������","�˳����ϴ�ս��"};
private JButton start;
static Element[] elementgp;
static int currentscore=0;
static int currenttime=0;
static boolean ready=false;
static int finalscore=0;
static int usedtime=0;
private JButton restore;

//����score��JLabel
public static JLabel returnsjb ()
{
	return MainFrame.score;
}

public MainFrame()
{
	//ʵ�ֻطŹ���ʱ����ʼ��deletenum
	backtrace.deletenum=new ArrayList<Integer>();
	
	
	//���÷���Ϊ0,�Լ�ʹ��ʱ��Ϊ0
	finalscore=0;
	usedtime=0;
	
	//����,��������������
	this.setTitle("������");
	background=new ImageIcon("src/lianliankan/cloud.jpg");
	int height=background.getIconHeight();
	int width=background.getIconWidth();
	backgroundlbl=new JLabel(background);
	backgroundlbl.setSize(width,height);
	imagepanel=(JPanel)this.getContentPane();
	imagepanel.setOpaque(false);
	imagepanel.setLayout(new FlowLayout(1,2000,30));
	titlepic=new ImageIcon("src/lianliankan/lianliankan.png");
	title=new JLabel(titlepic);
	imagepanel.add(title);
	
	//����play��ť�Լ�HELP��ʾ��
	ImageIcon playimg=new ImageIcon("src/lianliankan/playimage.png");
	play=new JButton(playimg);
	play.setFocusPainted(false);
	play.setBorderPainted(false);
	imagepanel.add(play);
	play.setOpaque(false);
	play.setContentAreaFilled(false);
	help=new JButton("HELP");
	help.setFont(new Font("Helvetica",Font.PLAIN, 35));
	play.setFocusPainted(false);
	help.setBorderPainted(false);
	imagepanel.add(help);
	
	//ΪHELP��ť���ӵ���¼�
	help.addMouseListener(new MouseAdapter()
			{
		public void mouseClicked(MouseEvent e) {
		       if(e.getButton()==e.BUTTON1){//���������
		    	   JOptionPane.showMessageDialog(null, "�ڹ涨ʱ���ھ����ܶ�ؽ���ͬ��2��ͼ���ò�����3����ֱ��������������������йؿ����ɽ����������а�ͬʱ��δˢ�¿�ʵ�ֻط�","��ʾ",3);
		    	   
		       }else if(e.getButton()==e.BUTTON2){//�����껬��  
		          ;   
		       }  
		       else if(e.getButton()==e.BUTTON3){//�������Ҽ�  
		          ; 
		       }
		       }  
			});
	
	//ΪPLAY��ť���ӵ���¼���������Ϸ���棩
	play.addMouseListener(new MouseAdapter()
	{
public void mouseClicked(MouseEvent e) {  
       if(e.getButton()==e.BUTTON1){//���������
    	   Object[] options = new Object[]{"��ʼ����Ϸ", "��ȡ�ϴα��ش浵", "�鿴�������а�","�ط��ϴε���Ϸ����"};
    	   int optionSelected = JOptionPane.showOptionDialog(
                   MainFrame.this,
                   "��ӭ����",
                   "��ʾ",
                   JOptionPane.YES_NO_CANCEL_OPTION,
                   JOptionPane.INFORMATION_MESSAGE,
                   new ImageIcon("src/lianliankan/chooseimage1.png"),
                   options,    // �����null, ��ťΪ optionType ��������ʾ�İ�ť��Ҳ����ȷ�϶Ի���
                   options[0]
           );
    	   
    	   //�����ȡ�ϴδ浵
    	   if(optionSelected==1)
    	   {
    		   JButton trace=new JButton("�����Ա�ط�");
    		   imagepanel.setLayout(new BorderLayout());
        	   play.setVisible(false);
        	   help.setVisible(false);
        	   title.setVisible(false);
        	   matrixpnl=new JPanel(new GridLayout(7,8));
        	   messagepnl=new JPanel(new FlowLayout(1,40,5));
        	   leftpnl=new JPanel();
        	   rightpnl=new JPanel();
        	   uppnl=new JPanel(new FlowLayout());
        	   reflash=new JButton("ˢ��");
        	   start=new JButton("��ʼ");
        	   restore=new JButton("���沢�˳�");
        	   reflash.setFocusPainted(false);
        	   start.setFocusPainted(false);
        	   restore.setFocusPainted(false);
        	   reflash.setFont(new Font(reflash.getFont().getName(), reflash.getFont().getStyle(), 20));
        	   reflash.setPreferredSize(new Dimension(100, 40));
        	   start.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 20));
        	   start.setPreferredSize(new Dimension(100, 40));
        	   restore.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 17));
        	   restore.setPreferredSize(new Dimension(120, 40));
        	   trace.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 15));
        	   trace.setPreferredSize(new Dimension(150, 40));
    		   elementgp=new Element[56];
    		   try
    		   {
    			   FileInputStream fis1=new FileInputStream("src/lianliankan/goongame.txt");
    			   InputStreamReader isr1=new InputStreamReader(fis1);
    			   BufferedReader br1=new BufferedReader(isr1);
    			   String line;
    			   for(int i=0;i<56;i++)
    			   {
    				   elementgp[i]=new Element();
    				   line=br1.readLine();
    				   if(Boolean.valueOf(line)==true)
    				   {
    					   elementgp[i].isclicked=true;
    				   }
    				   else
    				   {
    					   elementgp[i].isclicked=false;
    				   }
    			   }
    			   for(int i=0;i<56;i++)
    			   {
    				  
    				   line=br1.readLine();
    				   if(Boolean.valueOf(line)==true)
    				   {
    					   elementgp[i].ismatched=true;
    				   }
    				   else
    				   {
    					   elementgp[i].ismatched=false;
    				   }
    			   }
    			   for(int i=0;i<56;i++)
    			   {
    				   line=br1.readLine();
    				   if(line.equals("src/lianliankan/1.png"))
    				   elementgp[i].setIcon(patternimg.iconlt[0]);
    				   else if(line.equals("src/lianliankan/2.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[1]);
    				   else if(line.equals("src/lianliankan/3.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[2]);
    				   else if(line.equals("src/lianliankan/4.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[3]);
    				   else if(line.equals("src/lianliankan/5.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[4]);
    				   else if(line.equals("src/lianliankan/6.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[5]);
    				   else
        				   elementgp[i].setIcon(patternimg.iconlt[6]);
    			   }
    			   currenttime=Integer.parseInt(br1.readLine());
    			   currentscore=Integer.parseInt(br1.readLine());
    			   br1.close();
    		   }catch (Exception exc2)
    		   {
    			   exc2.printStackTrace();
    		   }
    		   for(int i=1;i<=56;i++)
        	   {
        		   matrixpnl.add(elementgp[i-1]);
        		   elementgp[i-1].setFocusPainted(false);
        		   elementgp[i-1].setBorder(BorderFactory.createLineBorder(Color.BLACK));
        	   }
    		   ArrayList<String> ic3=new ArrayList<String> ();
			   ArrayList<String> im3=new ArrayList<String>();
			   ArrayList<String> pc3=new ArrayList<String>();
			   for(int i=1;i<=56;i++)
			   {
				   ic3.add(Boolean.toString(elementgp[i-1].isclicked));
				   im3.add(Boolean.toString(elementgp[i-1].ismatched));
				   pc3.add(elementgp[i-1].getIcon().toString());
			   }
			   try
  			  {
  				  FileOutputStream fos3=new FileOutputStream("src/lianliankan/tracegame2.txt");
  				  OutputStreamWriter osw3=new OutputStreamWriter(fos3);
  				  BufferedWriter bw3=new BufferedWriter(osw3);
  				  for(int i=0;i<56;i++)
  				  {
  					  bw3.write(ic3.get(i));
  					  bw3.newLine();
  				  }
  				  for(int i=0;i<56;i++)
  				  {
  					  bw3.write(im3.get(i));
  					  bw3.newLine();
  				  }
  				 for(int i=0;i<56;i++)
 				  {
 					  bw3.write(pc3.get(i));
 					  bw3.newLine();
 				  }
  				 bw3.close();
  			  }catch (Exception exc)
 			   {
  				  exc.printStackTrace();
 			   }
			   
    		  
    		   scoretext=new JLabel("����:",JLabel.RIGHT);
        	   scoretext.setFont(new Font(scoretext.getFont().getName(), 
        			   scoretext.getFont().getStyle(), 20));
        	   scoretext.setPreferredSize(new Dimension(100, 40));
        	   timetext=new JLabel("����ʱ:",JLabel.RIGHT);
        	   timetext.setPreferredSize(new Dimension(100, 40));
        	   timetext.setFont(new Font(timetext.getFont().getName(), 
        			   timetext.getFont().getStyle(), 20));
        	   score=new JLabel(Integer.toString(currentscore));
        	   score.setPreferredSize(new Dimension(70, 40));
        	   score.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        	   score.setFont(new Font(score.getFont().getName(), 
        			   score.getFont().getStyle(), 20));
        	   time=new JLabel(Integer.toString(currenttime));
        	   time.setPreferredSize(new Dimension(70, 40));
        	   time.setFont(new Font(time.getFont().getName(), 
        			   time.getFont().getStyle(), 20));
        	   time.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        	   messagepnl.add(scoretext);
        	   messagepnl.add(score);
        	   messagepnl.add(timetext);
        	   messagepnl.add(time);
        	   
        	   
    		   //���Ӷ�����ƥ��Ԫ�صĲ���
    		   for(int i=0;i<56;i++)
        	   {
        		   if(elementgp[i].ismatched==true)
        		   {
        			   elementgp[i].setBorderPainted(false);
        			   elementgp[i].setVisible(false);
        		   }
        	   }
    		  
        	   
        	   //uppnl�����
        	   uppnl.add(reflash);
        	   uppnl.add(start);
        	   uppnl.add(restore);
        	   uppnl.add(trace);
        	   
        	   imagepanel.add(messagepnl,BorderLayout.SOUTH);
        	   imagepanel.add(matrixpnl,BorderLayout.CENTER);
        	   imagepanel.add(leftpnl,BorderLayout.WEST);
        	   imagepanel.add(rightpnl,BorderLayout.EAST);
        	   imagepanel.add(uppnl,BorderLayout.NORTH);
        	   messagepnl.setOpaque(false);
        	   uppnl.setOpaque(false);
        	   leftpnl.setOpaque(false);
        	   rightpnl.setOpaque(false);
        	   matrixpnl.setOpaque(false);
        	   matrixpnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),
        			   (imagepanel.getHeight()-100)));
        	   leftpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
        	   rightpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
        	   uppnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));
        	   messagepnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));

        	   //�����Ա�ط�
        	   trace.addMouseListener(new MouseAdapter(){
        		   public void mouseClicked(MouseEvent e)
        		   {
        			   try
          			  {
          				  FileOutputStream fos2=new FileOutputStream("src/lianliankan/tracegame.txt");
          				  OutputStreamWriter osw2=new OutputStreamWriter(fos2);
          				  BufferedWriter bw2=new BufferedWriter(osw2);
          				  int trlen=backtrace.deletenum.size();
          				  for(int p=0;p<trlen;p++)
          				  {
          					  bw2.write(Integer.toString(backtrace.deletenum.get(p)));
          					  bw2.newLine();
          				  }
          				 bw2.close();
          			  }catch (Exception exc)
         			   {
          				  exc.printStackTrace();
         			   }
        			
         			   System.exit(0);
        		   }
        	   });
        	   
        	   //���ر���
        	   restore.addMouseListener(new MouseAdapter()
        			   {
        		   public void mouseClicked(MouseEvent e)
        		   {
        			   ArrayList<String> ic=new ArrayList<String> ();
        			   ArrayList<String> im=new ArrayList<String>();
        			   ArrayList<String> pc=new ArrayList<String>();
        			   for(int i=1;i<=56;i++)
        			   {
        				   ic.add(Boolean.toString(elementgp[i-1].isclicked));
        				   im.add(Boolean.toString(elementgp[i-1].ismatched));
        				   pc.add(elementgp[i-1].getIcon().toString());
        			   }
        			   try
         			  {
         				  FileOutputStream fos1=new FileOutputStream("src/lianliankan/goongame.txt");
         				  OutputStreamWriter osw1=new OutputStreamWriter(fos1);
         				  BufferedWriter bw1=new BufferedWriter(osw1);
         				  for(int i=0;i<56;i++)
         				  {
         					  bw1.write(ic.get(i));
         					  bw1.newLine();
         				  }
         				  for(int i=0;i<56;i++)
         				  {
         					  bw1.write(im.get(i));
         					  bw1.newLine();
         				  }
         				 for(int i=0;i<56;i++)
        				  {
        					  bw1.write(pc.get(i));
        					  bw1.newLine();
        				  }
         				 bw1.write(Integer.toString(CountDown60.i));
         				 bw1.newLine();
         				 bw1.write(currentscore);
         				 bw1.newLine();//���һ�м�¼�÷֣������ڶ��м�¼����ʱ
         				 bw1.close();
         			  }catch (Exception exc)
        			   {
         				  exc.printStackTrace();
        			   }
        			   System.exit(0);
        		   }
        			   });
        	 
        	   //��Ϸ�����㷨

        	  for(Element z:elementgp)
        	   {
        		   z.addMouseListener(new MouseAdapter()
        				   {
        			   public void mouseClicked(MouseEvent e)
        			   {
        				   gamealg s=new gamealg();
        				   s.gameway(z, elementgp, 56, 7, 8, score, MainFrame.currentscore);
        			   }
        				   });
        		 
        	   }
        	   
        	   //���start����ʼ��Ϸ
        	   start.addMouseListener(new MouseAdapter()
        			   {
        		   public void mouseClicked(MouseEvent e)
        		   {
        			 
        			   CountDownRandom w2=new CountDownRandom(currenttime);
        			   w2.cd(time,MainFrame.this,matrixpnl,gameovergp,elementgp,56,7);
        			   MainFrame.ready=true;
        			  
        			
        		   }
        			   });
        	   
        	   //����ʱ��������Ҫˢ�µ�ǰͼ��ʱ���������ţ���ʼʱ������ˢ�£�
        	   reflash.addMouseListener(new MouseAdapter()
        			   {
        		   public void mouseClicked(MouseEvent e)
        		   {
        			   Reflash.renew(elementgp,56,matrixpnl);
        			   matrixpnl.setVisible(true);
        		   }
        		   
        			   });
    	   }
    	   
    	   //�����ʼ����Ϸ
    	   else if(optionSelected==0)
    	   {
    		   JButton trace=new JButton("�����Ա�ط�");
    		   imagepanel.setLayout(new BorderLayout());
    		           	   play.setVisible(false);
    		           	   help.setVisible(false);
    		           	   title.setVisible(false);
    		           	   matrixpnl=new JPanel(new GridLayout(7,8));
    		           	   messagepnl=new JPanel(new FlowLayout(1,40,5));
    		           	   leftpnl=new JPanel();
    		           	   rightpnl=new JPanel();
    		           	   uppnl=new JPanel(new FlowLayout());
    		           	   reflash=new JButton("ˢ��");
    		           	   start=new JButton("��ʼ");
    		           	   restore=new JButton("���沢�˳�");
    		           	   reflash.setFocusPainted(false);
    		           	   start.setFocusPainted(false);
    		           	   restore.setFocusPainted(false);
    		           	   reflash.setFont(new Font(reflash.getFont().getName(), reflash.getFont().getStyle(), 20));
    		           	   reflash.setPreferredSize(new Dimension(100, 40));
    		           	   start.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 20));
    		           	   start.setPreferredSize(new Dimension(100, 40));
    		           	   restore.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 17));
    		           	   restore.setPreferredSize(new Dimension(120, 40));
    		   trace.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 15));
    		           	   trace.setPreferredSize(new Dimension(150, 40));
    		           	   elementgp=new Element[56];
    		           	   for(int i=1;i<=56;i++)
    		           	   {
    		           		   elementgp[i-1]=new Element();
    		           	   }
    		           	   initialrange v=new initialrange();
    		           	   elementgp=v.initial(elementgp, 56, 7);
    		           	   for(int i=1;i<=56;i++)
    		           	   {
    		           		   matrixpnl.add(elementgp[i-1]);
    		           		   elementgp[i-1].setFocusPainted(false);
    		           		   elementgp[i-1].setBorder(BorderFactory.createLineBorder(Color.BLACK));
    		           	   }
    		   	 ArrayList<String> ic3=new ArrayList<String> ();
    		   			   ArrayList<String> im3=new ArrayList<String>();
    		   			   ArrayList<String> pc3=new ArrayList<String>();
    		   			   for(int i=1;i<=56;i++)
    		   			   {
    		   				   ic3.add(Boolean.toString(elementgp[i-1].isclicked));
    		   				   im3.add(Boolean.toString(elementgp[i-1].ismatched));
    		   				   pc3.add(elementgp[i-1].getIcon().toString());
    		   			   }
    		   			   try
    		     			  {
    		     				  FileOutputStream fos3=new FileOutputStream("src/lianliankan/tracegame2.txt");
    		     				  OutputStreamWriter osw3=new OutputStreamWriter(fos3);
    		     				  BufferedWriter bw3=new BufferedWriter(osw3);
    		     				  for(int i=0;i<56;i++)
    		     				  {
    		     					  bw3.write(ic3.get(i));
    		     					  bw3.newLine();
    		     				  }
    		     				  for(int i=0;i<56;i++)
    		     				  {
    		     					  bw3.write(im3.get(i));
    		     					  bw3.newLine();
    		     				  }
    		     				 for(int i=0;i<56;i++)
    		    				  {
    		    					  bw3.write(pc3.get(i));
    		    					  bw3.newLine();
    		    				  }
    		     				 bw3.close();
    		     			  }catch (Exception exc)
    		    			   {
    		     				  exc.printStackTrace();
    		    			   }
    		           	   scoretext=new JLabel("����:",JLabel.RIGHT);
    		           	   scoretext.setFont(new Font(scoretext.getFont().getName(), 
    		           			   scoretext.getFont().getStyle(), 20));
    		           	   scoretext.setPreferredSize(new Dimension(100, 40));
    		           	   timetext=new JLabel("����ʱ:",JLabel.RIGHT);
    		           	   timetext.setPreferredSize(new Dimension(100, 40));
    		           	   timetext.setFont(new Font(timetext.getFont().getName(), 
    		           			   timetext.getFont().getStyle(), 20));
    		           	   score=new JLabel("0");
    		           	   score.setPreferredSize(new Dimension(70, 40));
    		           	   score.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    		           	   score.setFont(new Font(score.getFont().getName(), 
    		           			   score.getFont().getStyle(), 20));
    		           	   time=new JLabel("90");
    		           	   time.setPreferredSize(new Dimension(70, 40));
    		           	   time.setFont(new Font(time.getFont().getName(), 
    		           			   time.getFont().getStyle(), 20));
    		           	   time.setBorder(BorderFactory.createLineBorder(Color.BLACK));
    		           	   messagepnl.add(scoretext);
    		           	   messagepnl.add(score);
    		           	   messagepnl.add(timetext);
    		           	   messagepnl.add(time);
    		   	//���Ӷ�����ƥ��Ԫ�صĲ���
    		       		   for(int i=0;i<56;i++)
    		           	   {
    		           		   if(elementgp[i].ismatched==true)
    		           		   {
    		           			   elementgp[i].setBorderPainted(false);
    		           			   elementgp[i].setVisible(false);
    		           		   }
    		           	   }
    		           	   
    		           	   //uppnl�����
    		           	   uppnl.add(reflash);
    		           	   uppnl.add(start);
    		           	   uppnl.add(restore);
    		   	uppnl.add(trace);
    		           	   
    		           	   imagepanel.add(messagepnl,BorderLayout.SOUTH);
    		           	   imagepanel.add(matrixpnl,BorderLayout.CENTER);
    		           	   imagepanel.add(leftpnl,BorderLayout.WEST);
    		           	   imagepanel.add(rightpnl,BorderLayout.EAST);
    		           	   imagepanel.add(uppnl,BorderLayout.NORTH);
    		           	   messagepnl.setOpaque(false);
    		           	   uppnl.setOpaque(false);
    		           	   leftpnl.setOpaque(false);
    		           	   rightpnl.setOpaque(false);
    		           	   matrixpnl.setOpaque(false);
    		           	   matrixpnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),
    		           			   (imagepanel.getHeight()-100)));
    		           	   leftpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
    		           	   rightpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
    		           	   uppnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));
    		           	   messagepnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));

    		   //�����Ա�ط�
    		           	   trace.addMouseListener(new MouseAdapter(){
    		           		   public void mouseClicked(MouseEvent e)
    		           		   {
    		           			   try
    		             			  {
    		             				  FileOutputStream fos2=new FileOutputStream("src/lianliankan/tracegame.txt");
    		             				  OutputStreamWriter osw2=new OutputStreamWriter(fos2);
    		             				  BufferedWriter bw2=new BufferedWriter(osw2);
    		             				  int trlen=backtrace.deletenum.size();
    		             				  for(int p=0;p<trlen;p++)
    		             				  {
    		             					  bw2.write(Integer.toString(backtrace.deletenum.get(p)));
    		             					  bw2.newLine();
    		             				  }
    		             				 bw2.close();
    		             			  }catch (Exception exc)
    		            			   {
    		             				  exc.printStackTrace();
    		            			   }
    		           			
    		            			   System.exit(0);
    		           		   }
    		           	   });

    		           	   //���ر���
    		           	   restore.addMouseListener(new MouseAdapter()
    		           			   {
    		           		   public void mouseClicked(MouseEvent e)
    		           		   {
    		           			   ArrayList<String> ic=new ArrayList<String> ();
    		           			   ArrayList<String> im=new ArrayList<String>();
    		           			   ArrayList<String> pc=new ArrayList<String>();
    		           			   for(int i=1;i<=56;i++)
    		           			   {
    		           				   ic.add(Boolean.toString(elementgp[i-1].isclicked));
    		           				   im.add(Boolean.toString(elementgp[i-1].ismatched));
    		           				   pc.add(elementgp[i-1].getIcon().toString());
    		           			   }
    		           			   try
    		            			  {
    		            				  FileOutputStream fos1=new FileOutputStream("src/lianliankan/goongame.txt");
    		            				  OutputStreamWriter osw1=new OutputStreamWriter(fos1);
    		            				  BufferedWriter bw1=new BufferedWriter(osw1);
    		            				  for(int i=0;i<56;i++)
    		            				  {
    		            					  bw1.write(ic.get(i));
    		            					  bw1.newLine();
    		            				  }
    		            				  for(int i=0;i<56;i++)
    		            				  {
    		            					  bw1.write(im.get(i));
    		            					  bw1.newLine();
    		            				  }
    		            				 for(int i=0;i<56;i++)
    		           				  {
    		           					  bw1.write(pc.get(i));
    		           					  bw1.newLine();
    		           				  }
    		            				 bw1.write(Integer.toString(CountDown60.i));
    		            				 bw1.newLine();
    		            				 bw1.write(Integer.toString(currentscore));
    		            				 bw1.newLine();//���һ�м�¼�÷֣������ڶ��м�¼����ʱ
    		            				 bw1.close();
    		            			  }catch (Exception exc)
    		           			   {
    		            				  exc.printStackTrace();
    		           			   }
    		           			   System.exit(0);
    		           		   }
    		           			   });
    		           	 
    		           	   //��Ϸ�����㷨

    		           	  for(Element z:elementgp)
    		           	   {
    		           		   z.addMouseListener(new MouseAdapter()
    		           				   {
    		           			   public void mouseClicked(MouseEvent e)
    		           			   {
    		           				   gamealg s=new gamealg();
    		           				   s.gameway(z, elementgp, 56, 7, 8, score, MainFrame.this.currentscore);
    		           			   }
    		           				   });
    		           		 
    		           	   }
    		           	   
    		           	   //���start����ʼ��Ϸ
    		           	   start.addMouseListener(new MouseAdapter()
    		           			   {
    		           		   public void mouseClicked(MouseEvent e)
    		           		   {
    		           			 
    		           			   CountDown60 w=new CountDown60();
    		           			   w.cd60(time,MainFrame.this,matrixpnl,gameovergp,elementgp,56,7);
    		           			   MainFrame.ready=true;
    		           			  
    		           			
    		           		   }
    		           			   });
    		           	   
    		           	   //����ʱ��������Ҫˢ�µ�ǰͼ��ʱ���������ţ���ʼʱ������ˢ�£�
    		           	   reflash.addMouseListener(new MouseAdapter()
    		           			   {
    		           		   public void mouseClicked(MouseEvent e)
    		           		   {
    		           			   Reflash.renew(elementgp,56,matrixpnl);
    		           			   matrixpnl.setVisible(true);
    		           		   }
    		           		   
    		           			   });
    		           	   
        	   
    	   }
    	   
    	   //�鿴���а�
    	   else if(optionSelected==2)
    	   {
    		   new Client("true").createcl();
    		   int num=listdata.iddata.size();
    		   Object[][] tabledata = new Object[num][2];
    		   for(int sl=0;sl<num;sl++)
    		   {
    			   tabledata[sl]=new Object[] {listdata.iddata.get(num-1-sl),listdata.scoredata.get(num-1-sl)};
    		   }
    		   imagepanel.setLayout(new BorderLayout());
    		   JButton back =new JButton("ȷ��");
    		   Object[] columntitle = {"�û���" , "��ʱ" };
    		  JTable table = new JTable(tabledata , columntitle);
    		  JScrollPane jsp=new JScrollPane(table);
    		  jsp.add(back);
    		  back.setVisible(true);
       	      play.setVisible(false);
       	      help.setVisible(false);
       	      title.setVisible(false);
    		  imagepanel.add(jsp,BorderLayout.CENTER);
    		  JPanel backjp=new JPanel();
    		  backjp.add(back);
    		  imagepanel.add(backjp,BorderLayout.SOUTH);
    		  jsp.setVisible(true);
    		  table.setVisible(true);
    		  back.addMouseListener(new MouseAdapter()
    			{
    			  public void mouseClicked(MouseEvent e) {  
    			         if(e.getButton()==e.BUTTON1){//���������
    			        	 jsp.setVisible(false);
    			        	 backjp.setVisible(false);
    			        	 play.setVisible(true);
    			       	      help.setVisible(true);
    			       	      title.setVisible(true);

    			         }
    			         else if(e.getButton()==e.BUTTON2){//�����껬��  
    			             ;   
    			          }  
    			          else if(e.getButton()==e.BUTTON3){//�������Ҽ�  
    			             ; 
    			          }
    			         }
    			});
    	   }
    	   //�鿴�ط�
    	   else if(optionSelected==3)
    	   {
    		   backtrace.totaldel=0;
    		   imagepanel.setLayout(new BorderLayout());
        	   play.setVisible(false);
        	   help.setVisible(false);
        	   title.setVisible(false);
        	   matrixpnl=new JPanel(new GridLayout(7,8));
        	   messagepnl=new JPanel(new FlowLayout(1,40,5));
        	   leftpnl=new JPanel();
        	   rightpnl=new JPanel();
        	   uppnl=new JPanel(new FlowLayout());
        	   reflash=new JButton("ˢ��");
        	   start=new JButton("��ʼ");
        	   restore=new JButton("���沢�˳�");
        	   reflash.setFocusPainted(false);
        	   start.setFocusPainted(false);
        	   restore.setFocusPainted(false);
        	   reflash.setFont(new Font(reflash.getFont().getName(), reflash.getFont().getStyle(), 20));
        	   reflash.setPreferredSize(new Dimension(100, 40));
        	   start.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 20));
        	   start.setPreferredSize(new Dimension(100, 40));
        	   restore.setFont(new Font(start.getFont().getName(), start.getFont().getStyle(), 17));
        	   restore.setPreferredSize(new Dimension(120, 40));
    		   elementgp=new Element[56];
    		   try
    		   {
    			   FileInputStream fis1=new FileInputStream("src/lianliankan/tracegame2.txt");
    			   InputStreamReader isr1=new InputStreamReader(fis1);
    			   BufferedReader br1=new BufferedReader(isr1);
    			   String line;
    			   for(int i=0;i<56;i++)
    			   {
    				   elementgp[i]=new Element();
    				   line=br1.readLine();
    				   if(Boolean.valueOf(line)==true)
    				   {
    					   elementgp[i].isclicked=true;
    				   }
    				   else
    				   {
    					   elementgp[i].isclicked=false;
    				   }
    			   }
    			   for(int i=0;i<56;i++)
    			   {
    				  
    				   line=br1.readLine();
    				   if(Boolean.valueOf(line)==true)
    				   {
    					   elementgp[i].ismatched=true;
    				   }
    				   else
    				   {
    					   elementgp[i].ismatched=false;
    				   }
    			   }
    			   for(int i=0;i<56;i++)
    			   {
    				   line=br1.readLine();
    				   if(line.equals("src/lianliankan/1.png"))
    				   elementgp[i].setIcon(patternimg.iconlt[0]);
    				   else if(line.equals("src/lianliankan/2.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[1]);
    				   else if(line.equals("src/lianliankan/3.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[2]);
    				   else if(line.equals("src/lianliankan/4.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[3]);
    				   else if(line.equals("src/lianliankan/5.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[4]);
    				   else if(line.equals("src/lianliankan/6.png"))
        				   elementgp[i].setIcon(patternimg.iconlt[5]);
    				   else
        				   elementgp[i].setIcon(patternimg.iconlt[6]);
    			   }
    			   br1.close();
    		   }catch (Exception exc2)
    		   {
    			   exc2.printStackTrace();
    		   }
    		   for(int i=1;i<=56;i++)
        	   {
        		   matrixpnl.add(elementgp[i-1]);
        		   elementgp[i-1].setFocusPainted(false);
        		   elementgp[i-1].setBorder(BorderFactory.createLineBorder(Color.BLACK));
        	   }
    		   //���Ӷ�����ƥ��Ԫ�صĲ���
    		   for(int i=0;i<56;i++)
        	   {
        		   if(elementgp[i].ismatched==true)
        		   {
        			   elementgp[i].setBorderPainted(false);
        			   elementgp[i].setVisible(false);
        		   }
        	   }
    		   //uppnl�����
        	   uppnl.add(reflash);
        	   uppnl.add(start);
        	   uppnl.add(restore);
        	   reflash.setVisible(false);
        	   start.setVisible(false);
        	   restore.setVisible(false);
        	   
        	   imagepanel.add(messagepnl,BorderLayout.SOUTH);
        	   imagepanel.add(matrixpnl,BorderLayout.CENTER);
        	   imagepanel.add(leftpnl,BorderLayout.WEST);
        	   imagepanel.add(rightpnl,BorderLayout.EAST);
        	   imagepanel.add(uppnl,BorderLayout.NORTH);
        	   messagepnl.setOpaque(false);
        	   uppnl.setOpaque(false);
        	   leftpnl.setOpaque(false);
        	   rightpnl.setOpaque(false);
        	   matrixpnl.setOpaque(false);
        	   matrixpnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),
        			   (imagepanel.getHeight()-100)));
        	   leftpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
        	   rightpnl.setPreferredSize(new Dimension(150,(imagepanel.getHeight()-90)));
        	   uppnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));
        	   messagepnl.setPreferredSize(new Dimension((imagepanel.getWidth()-300),50));
        	   JButton tracer=new JButton("��һ��");
        	   messagepnl.add(tracer);

        	   tracer.addMouseListener(new MouseAdapter(){
        		   public void mouseClicked(MouseEvent e)
        		   {
        			 
        			   int i=0;
        			   try
            		   {
            			   FileInputStream fis4=new FileInputStream("src/lianliankan/tracegame.txt");
            			   InputStreamReader isr4=new InputStreamReader(fis4);
            			   BufferedReader br4=new BufferedReader(isr4);
            			   String line="111";
            			  
            			   while((i<=backtrace.totaldel)&&(((line=br4.readLine())!=null)))
            			   {
            				   i++;
            			   }
            			   if((line!=null)&&(line!="111"))
            			   {
            			   elementgp[Integer.parseInt(line)].setVisible(false);
            			   backtrace.totaldel++;
            			   }
            			   else
            			   {
            				   System.exit(0);
            			   }
            			   br4.close();
            		   }catch(Exception excv)
        			   {
            			   excv.printStackTrace();
        			   }
        		   }
        	   });
    	   }
       }else if(e.getButton()==e.BUTTON2){//�����껬��  
          ;   
       }  
       else if(e.getButton()==e.BUTTON3){//�������Ҽ�  
          ; 
       }
       }  
	});
	//��������
	this.getLayeredPane().add(backgroundlbl, new Integer(Integer.MIN_VALUE));
	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//�ļ��ܹ��ر�
			 this.setSize(width,height);
			 this.setLocationRelativeTo(null);
			this.setVisible(true);	
}
public static void main(String[] args)
{
	MainFrame host=new MainFrame();
}
}
