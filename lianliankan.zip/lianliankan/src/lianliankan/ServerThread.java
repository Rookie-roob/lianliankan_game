package lianliankan;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;

public class ServerThread implements Runnable{
private Socket s;
public ServerThread(Socket s)
{
	this.s=s;
}
public void run()
{
	try
	{
		InputStream is1=s.getInputStream();
		byte[] bytes1=new byte[2048];
		int len1=is1.read(bytes1);
		String message=new String(bytes1,0,len1);
		//�յ�����Ϣ����true
		if(!message.equals("true"))
		{
			char[] mes=message.toCharArray();
			int clen=mes.length;
			int i;
			for(i=(clen-1);i>=0;i--)
			{
				if(mes[i]==' ')
					break;
			}
			String id=new String(mes,0,i);
			String score=new String(mes,(i+1),(clen-i-1));
			int scores=Integer.parseInt(score);
			record(id,score);
			s.shutdownInput();
			s.close();//��������
		}
		//�յ�����Ϣ��true
		else
		{
			//��ȡ���а���Ϣ
			BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream("src/lianliankan/rating.txt")));
			String line;
			ArrayList<String> idlist=new ArrayList<String>();
			ArrayList<String> scorelist=new ArrayList<String>();
			ArrayList<Integer> scoreslist=new ArrayList<Integer>();
			int flag=1;
			while((line=br.readLine())!=null)
			{
				if(flag%2==1)
				{
					idlist.add(line);
					flag++;
				}
				else
				{
					scorelist.add(line);
					flag++;
				}
			}
			br.close();
			int num=flag-1;
			String temp;
			for(int j=1;j<=(num/2);j++)
			{
				temp=scorelist.get(j-1);
				scoreslist.add(Integer.parseInt(temp));
			}
			//������Ϣ��������
			String[] array1=(String[])idlist.toArray(new String[num]);
			Integer[] array2=(Integer[])scoreslist.toArray(new Integer[num]);
			//ð������
			int bubbletemp;
			String bubbletemp2;
			for(int j=0;j<((num/2)-1);j++)
			{
				for(int k=((num/2)-1);k>j;k--)
				{
					if(array2[k]<array2[k-1])
					{
						bubbletemp=array2[k];
						array2[k]=array2[k-1];
						array2[k-1]=bubbletemp;
						bubbletemp2=array1[k];
						array1[k]=array1[k-1];
						array1[k-1]=bubbletemp2;
					}
				}
			}
			
			//��ͻ���д��Ϣ
			BufferedWriter bw2=new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
			for(int j=1;j<=(num/2);j++)
			{
				bw2.write(array1[(num/2)-j]);
				bw2.newLine();
				bw2.flush();
				bw2.write(Integer.toString(array2[(num/2)-j]));
				bw2.newLine();
				bw2.flush();
			}
			s.shutdownOutput();
		}
	
	}catch(Exception e)
	{
		e.printStackTrace();
	}
}
public void record(String id,String score)
{
	//�����յ���id�Լ�score��Ϣ��¼���������ϵ�һ���ı��ļ���
	try
	{
		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream("src/lianliankan/rating.txt",true)));
		bw.write(id);
		bw.newLine();
		bw.write(score);
		bw.newLine();
		bw.close();
	}catch(Exception e)
	{
		e.printStackTrace();
	}
}
}
