package lianliankan;

import java.util.ArrayList;

public class listdata {
static ArrayList<String> iddata;
static ArrayList<String> scoredata;
}
