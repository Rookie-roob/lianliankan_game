package lianliankan;
import java.util.*;
public class RandomList {
public static ArrayList<Integer> returnlist (int k)
{
	ArrayList<Integer> a=new ArrayList<Integer>();
	Random rand=new Random();
	int size=0;
	while(size<k)
	{
		size=a.size();
		if(size==0)
		{
		a.add(new Integer(rand.nextInt(k)));
		}
		else
		{
			int temp=rand.nextInt(k);
			int p=0;
			while(p<size)
			{
				if(temp==a.get(p))
				{
					p=-1;
					temp=rand.nextInt(k);
				}
				p++;
			}
			a.add(new Integer(temp));
		}
		size=a.size();
	}
	return a;

}
/*public static void main(String[] args)
{
	System.out.println(RandomList.returnlist(30));
}*/
}
