package lianliankan;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;

public class gamealg {
public void gameway(Element x,Element[] elementgp,int num,int hang,int lie,JLabel scorejb,int currentscore)
{
	if(MainFrame.ready)
	{
	//����ÿ�����ť�ı��������
	if((x.isclicked==false)&&(x.ismatched==false))
	{
		x.setFocusPainted(true);
		x.isclicked=true;
		x.setBorder(BorderFactory.createLineBorder(Color.RED));
	}
	else
	{
		x.setFocusPainted(true);
		x.isclicked=false;
		x.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	}
	//�������飬�жϱ�����ĸ����Ƿ�Ϊ2��
	int clicknum=0;
	for(int i=0;i<num;i++)
	{
		if((elementgp[i].isclicked==true)&&(elementgp[i].ismatched==false))
			clicknum++;
	}
	if(clicknum!=2)
	{
		return;
	}
	else
	{
		//��¼�������������ť���±꣬�Լ����Ƕ�Ӧ�������Լ�������ϰ���ϵ������Լ�������
		int n1;
		int n2;
		int[] list=new int[2];
		int j=0;
		for(int i=0;i<num;i++)
		{
			if(elementgp[i].isclicked==true)
			{
				list[j]=i;
				j++;
			}
		}		
		n1=list[0];
		n2=list[1];
		int hang1=n1/lie+1;
		int lie1=n1%lie+1;
		int hang2=n2/lie+1;
		int lie2=n2%lie+1;
		if(elementgp[n1].getIcon()==elementgp[n2].getIcon())
		{
		//�ж�������ť�ǲ�������
		if(isnear(hang1,hang2,lie1,lie2)) {

			currentscore=match(elementgp[n1],elementgp[n2],scorejb,currentscore);
			backtrace.deletenum.add(n1);
			backtrace.deletenum.add(n2);
		}
		//�ж�2����ť�ǲ���0��
		else if(zerobend(hang1,hang2,lie1,lie2,n1,n2,lie,elementgp))
		{
			currentscore=match(elementgp[n1],elementgp[n2],scorejb,currentscore);
			backtrace.deletenum.add(n1);
			backtrace.deletenum.add(n2);
		}
		//�ж�2����ť�ǲ���1��
		else if(onebend(hang1,hang2,lie1,lie2,n1,n2,lie,elementgp))
		{
			currentscore=match(elementgp[n1],elementgp[n2],scorejb,currentscore);
			backtrace.deletenum.add(n1);
			backtrace.deletenum.add(n2);
		}
		//�ж�2����ť�ǲ���2��
		else if(twobend(hang1,hang2,lie1,lie2,n1,n2,hang,lie,elementgp))
		{
			currentscore=match(elementgp[n1],elementgp[n2],scorejb,currentscore);
			backtrace.deletenum.add(n1);
			backtrace.deletenum.add(n2);
		}
		else
		{
			;
		}
		}
		else
			return;
	}
	}
}

//ƥ�亯��
public int match(Element x,Element y,JLabel scorejb,int currentscore)
{
	x.ismatched=true;
	y.ismatched=true;
	x.isclicked=false;
	y.isclicked=false;
	x.setBorderPainted(false);
	y.setBorderPainted(false);
	x.setVisible(false);
	y.setVisible(false);
	MainFrame.currentscore=currentscore+2;
	scorejb.setText(MainFrame.currentscore+"");
	scorejb.setFont(new Font(scorejb.getFont().getName(), 
			   scorejb.getFont().getStyle(), 20));
	return MainFrame.currentscore;
}

//�ж��Ƿ�����
public boolean isnear(int hang1,int hang2,int lie1,int lie2)
{
	if(((((hang1-hang2)==1)||((hang2-hang1)==1))&&(lie1==lie2))||
			((((lie1-lie2)==1)||((lie2-lie1)==1))&&(hang1==hang2)))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//�ж��ǲ���0��
public boolean zerobend(int hang1,int hang2,int lie1,int lie2,int n1,int n2,int lie,Element[] a)
{
	if((hang1==hang2)&&(onehang(n1,n2,a)))
	{
		return true;
	}
	else if((lie1==lie2)&&(onelie(n1,n2,lie,a)))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//�ж��ǲ���1��
public boolean onebend(int hang1,int hang2,int lie1,int lie2,int n1,int n2,int lie,Element[] a)
{
	int hang3=hang1;
	int lie3=lie2;
	int n3=(hang3-1)*lie+lie3-1;
	int hang4=hang2;
	int lie4=lie1;
	int n4=(hang4-1)*lie+lie4-1;
	if((zerobend(hang1,hang3,lie1,lie3,n1,n3,lie,a))&&(zerobend(hang3,hang2,lie3,lie2,n3,n2,lie,a))&&(a[n3].ismatched==true))
	{
		return true;
	}
	else if((zerobend(hang1,hang4,lie1,lie4,n1,n4,lie,a))&&(zerobend(hang4,hang2,lie4,lie2,n4,n2,lie,a))&&(a[n4].ismatched==true))
	{
		return true;
	}
	else
	{
		return false;
	}
	
}

//�ж��ǲ���2��
public boolean twobend(int hang1,int hang2,int lie1,int lie2,int n1,int n2,int hang,int lie,Element[] a)
{
	//�ж��ǲ�������Χ
	if((hang1==1)&&(hang2==1))
		return true;
	else if((lie1==1)&&(lie2==1))
		return true;
	else if((hang1==hang)&&(hang2==hang))
		return true;
	else if((lie1==lie)&&(lie2==lie))
		return true;
	//��������Χ�����
	else if(hangzero(hang1,hang2,lie1,lie2,n1,n2,lie,a))
		return true;
	else if(liezero(hang1,hang2,lie1,lie2,n1,n2,hang,lie,a))
		return true;
	else if(zuoempty(hang1,hang2,lie1,lie2,lie,a)||youempty(hang1,hang2,lie1,lie2,lie,a)
			||shangempty(hang1,hang2,lie1,lie2,lie,a)||xiaempty(hang1,hang2,lie1,lie2,hang,lie,a))
		return true;
	else
		return false;
}
//�ж�һ���ڵ�2����ť֮���Ƿ��ѱ�ƥ��
public boolean onehang(int n3,int n4,Element[] a)
{
	boolean flag=true;
	int n1=(n3>n4)?n4:n3;
	int n2=(n3>n4)?n3:n4;
	for(int i=(n1+1);i<n2;i++)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	return flag;
}

//�ж�һ���ڵ�2����ť֮���Ƿ��ѱ�ƥ��
public boolean onelie(int n3,int n4,int lie,Element[] a)
{
	int n1=(n3>n4)?n4:n3;
	int n2=(n3>n4)?n3:n4;
	boolean flag=true;
	for(int i=(n1+lie);i<n2;i=i+lie)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	return flag;
}

//���������0��Ϊˮƽ(�����ʼ)
public boolean hangzero(int hang3,int hang4,int lie3,int lie4,int n3,int n4,int lie,Element[] a)
{
	int lie5=(lie3>lie4)?lie4:lie3;
	int lie6=(lie3>lie4)?lie3:lie4;
	int hang5=(lie3>lie4)?hang4:hang3;
	int hang6=(lie3>lie4)?hang3:hang4;
	int n5=(lie3>lie4)?n4:n3;
	int n6=(lie3>lie4)?n3:n4;
	boolean flag=false;
	for(int i=(n5+1);i<=(hang5*lie-1);i++)//���ұ�����
	{
		if((a[i].ismatched==true)&&((isnear(hang5,hang5,lie5,(i-n5+lie5)))||
				(zerobend(hang5,hang5,lie5,(i-n5+lie5),n5,i,lie,a)))&&
		(onebend(hang5,hang6,(i-n5+lie5),lie6,i,n6,lie,a)))
		{
			flag=true;
			break;
		}
	}
	if(flag==true)
	{
	return flag;
	}
	else//Ҳ�п���0��ʱ���������
	{
		if(lie5==1)
		{
			return flag;
		}
		else
		{
			for(int i=((hang5-1)*lie);i<n5;i++)
			{
				if((a[i].ismatched==true)&&((isnear(hang5,hang5,((i-(hang5-1)*lie)+1),lie5))||
						(zerobend(hang5,hang5,((i-(hang5-1)*lie)+1),lie5,i,n5,lie,a)))&&
				(onebend(hang5,hang6,((i-(hang5-1)*lie)+1),lie6,i,n6,lie,a)))
				{
					flag=true;
					break;
				}
			}
			return flag;
		}
	}
}

//���������0��Ϊ��ֱ(���Ϊ��ʼ)
public boolean liezero(int hang3,int hang4,int lie3,int lie4,int n3,int n4,int hang,int lie,Element[] a)
{
	int lie5=(lie3>lie4)?lie4:lie3;
	int lie6=(lie3>lie4)?lie3:lie4;
	int hang5=(lie3>lie4)?hang4:hang3;
	int hang6=(lie3>lie4)?hang3:hang4;
	int n5=(lie3>lie4)?n4:n3;
	int n6=(lie3>lie4)?n3:n4;
	boolean flag=false;
	for(int i=(lie5-1);i<=((hang-1)*lie+lie5-1);i=i+lie)
	{
		if((i!=n5)&&(a[i].ismatched==true)&&
				((isnear(hang5,(((i-(lie5-1))/lie)+1),lie5,lie5))||
				(zerobend(hang5,(((i-(lie5-1))/lie)+1),lie5,lie5,n5,i,lie,a)))&&
		(onebend((((i-(lie5-1))/lie)+1),hang6,lie5,lie6,i,n6,lie,a)))
		{
			flag=true;
			break;
		}
	}
	return flag;
}

//������������ȫΪ��
public boolean zuoempty(int hang3,int hang4,int lie3,int lie4,int lie,Element[] a)
{
	boolean flag=true;
	for(int i=((hang3-1)*lie);i<((hang3-1)*lie+lie3-1);i++)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	if(flag==true)
	{
		for(int i=((hang4-1)*lie);i<((hang4-1)*lie+lie4-1);i++)
		{
			if(a[i].ismatched==false)
			{
				flag=false;
				break;
			}
		}
	}
	else
	{
		;
	}
	return flag;
}

//����������Ҳ�ȫΪ��
public boolean youempty(int hang3,int hang4,int lie3,int lie4,int lie,Element[] a)
{
	boolean flag=true;
	for(int i=((hang3-1)*lie+lie3);i<=((hang3-1)*lie+lie-1);i++)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	if(flag==true)
	{
		for(int i=((hang4-1)*lie+lie4);i<=((hang4-1)*lie+lie-1);i++)
		{
			if(a[i].ismatched==false)
			{
				flag=false;
				break;
			}
		}
	}
	else
	{
		;
	}
	return flag;
}

//����������ϲ�ȫΪ��
public boolean shangempty(int hang3,int hang4,int lie3,int lie4,int lie,Element[] a)
{
	boolean flag=true;
	for(int i=(lie3-1);i<((hang3-1)*lie+lie3-1);i=i+lie)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	if(flag==true)
	{
		for(int i=(lie4-1);i<((hang4-1)*lie+lie4-1);i=i+lie)
		{
			if(a[i].ismatched==false)
			{
				flag=false;
				break;
			}
		}
	}
	else
	{
		;
	}
	return flag;
}

//����������²�ȫΪ��
public boolean xiaempty(int hang3,int hang4,int lie3,int lie4,int hang,int lie,Element[] a)
{
	boolean flag=true;
	for(int i=((hang-1)*lie+lie3-1);i>((hang3-1)*lie+lie3-1);i=i-lie)
	{
		if(a[i].ismatched==false)
		{
			flag=false;
			break;
		}
	}
	if(flag==true)
	{
		for(int i=((hang-1)*lie+lie4-1);i>((hang4-1)*lie+lie4-1);i=i-lie)
		{
			if(a[i].ismatched==false)
			{
				flag=false;
				break;
			}
		}
	}
	else
	{
		;
	}
	return flag;
}
//����ֵ����
public int alwaysplus(int x1,int x2)
{
	int x3=x1-x2;
	if(x3>=0)
	{
		return x3;
	}
	else
	{
		return (0-x3);
	}
}
}
